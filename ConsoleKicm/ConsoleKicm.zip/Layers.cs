﻿namespace ConsoleKicm;


//yy i know it's kinda stinky, but what i can say, it works
public class Layers
{
    public const int UI = 10;
    public const int STATIC = 4;// planet is static for instance
    public const int IMPORTANT = 3;
    public const int ZONE = 2;
    public const int BACKGROUND = 1;
    public const int LASER = 5;
}